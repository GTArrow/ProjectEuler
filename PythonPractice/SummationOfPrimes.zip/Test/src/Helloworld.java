
public class Helloworld {
	public static boolean isPrime(int n) {
		boolean a = true;
		if (n==0 || n==1 ) {
			a=false;
			return a;
		}
		else {
		for (int i=2;i<n/2+1;i++) {
			if (n%i==0){
				a=false;
				break;
			}
			else {
				a = true;
				}
			}
		return a;
	}
	}
	public static void main(String[] args) {

		System.out.println(Helloworld.isPrime(4));
	
}
}
