
public class Worker extends Thread{
    int[] a;
    int lower, upper,k;
    double[] s;
    
	public static boolean isPrime(int n) {
		boolean a = true;
		if (n==0 || n==1 ) {
			a=false;
			return a;
		}
		else {
		for (int i=2;i<n/2+1;i++) {
			if (n%i==0){
				a=false;
				break;
			}
			else {
				a = true;
				}
			}
		return a;
	}
	}
	
    public Worker(int[] a, int lower, int upper,int k, double[] s) {
        this.a = a; this.s =s; this.k = k;
        this.lower = lower; this.upper = upper;
    }
        public void run() {
        for (int i = lower; i < upper; i++) {
        	if (Worker.isPrime(a[i])) {
        		s[k] += a[i];
        	}
        }
        return;
    }

}
