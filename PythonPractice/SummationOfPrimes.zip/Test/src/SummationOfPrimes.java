
public class SummationOfPrimes {
	static double parallelaverage(int a[]) {
        final double[] s = new double[2];
        Worker w0 = new Worker(a, 0, a.length/2, 0, s); 
        Worker w1 = new Worker(a, a.length/2, a.length,1,s); 
        w0.start(); w1.start();
        try {
            w0.join(); w1.join();
        } catch (Exception e) {}
        return s[0]+s[1];
    }
    public static void main(String args[]) {
        int n = Integer.parseInt(args[0]); 
        int[] a = new int[n];
        for (int i = 0; i < n; i++) a[i] = i+1;
        double avg;
        avg = parallelaverage(a);
        System.out.println(avg );
    }
}

